from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
       QApplication, QWidget,
       QTableWidget, QListWidget, QListWidgetItem,
       QLineEdit, QFormLayout,
       QHBoxLayout, QVBoxLayout,
       QGroupBox, QButtonGroup, QRadioButton, 
       QPushButton, QLabel, QSpinBox)

card_win = QWidget()

#Інтерфейс
btn_menu = QPushButton("Меню")
btn_sleep = QPushButton("Відпочити")
box_min = QSpinBox()
box_min.setValue(30)
lbl_min = QLabel("хвилин")

#питання
lbl_question = QLabel("")

#варіанти відповідей
RadioGroupBox = QGroupBox("Варіанти відповідей")
RadioGroup = QButtonGroup()

#кнопки
rbtn1 = QRadioButton("")
rbtn2 = QRadioButton("")
rbtn3 = QRadioButton("")
rbtn4 = QRadioButton("")

#додавання кнопок 
RadioGroup.addButton(rbtn1)
RadioGroup.addButton(rbtn2)
RadioGroup.addButton(rbtn3)
RadioGroup.addButton(rbtn4)

#
AnswerGroupBox = QGroupBox("Результат тесту")
lbl_result = QLabel("")
lbl_correct = QLabel("")

#створення ліній
line_rbtn1 = QHBoxLayout()
line_rbtn2 = QHBoxLayout()
line_main = QVBoxLayout()

#лінії по горизонталі
line_rbtn1.addWidget(rbtn1)
line_rbtn1.addWidget(rbtn2)
line_rbtn2.addWidget(rbtn3)
line_rbtn2.addWidget(rbtn4)

#лінія по вертикалі
line_main.addLayout(line_rbtn1)
line_main.addLayout(line_rbtn2)

#відображаємо лінію в RadioGroupBox
RadioGroupBox.setLayout(line_main)

#
line_answer = QVBoxLayout()
line_answer.addWidget(lbl_result, alignment=(Qt.AlignLeft | Qt.AlignTop))
line_answer.addWidget(lbl_result, alignment=Qt.AlignHCenter, stretch=2)

#
AnswerGroupBox.setLayout(line_answer)
AnswerGroupBox.hide()

#
btn_ok = QPushButton("Відповісти")

#
line1 = QHBoxLayout()
line2 = QHBoxLayout()
line3 = QHBoxLayout()
line4 = QHBoxLayout()
card_layout = QVBoxLayout()

#розміщення інтерфейсу
line1.addWidget(btn_menu)
line1.addStretch(2)
line1.addWidget(btn_sleep)
line1.addWidget(box_min)
line1.addWidget(lbl_min)

line2.addWidget(lbl_question, alignment=(Qt.AlignHCenter | Qt.AlignVCenter))

line3.addWidget(RadioGroupBox)
line3.addWidget(AnswerGroupBox)

line4.addStretch(1)
line4.addWidget(btn_ok, stretch=2)
line4.addStretch(1)

card_layout.addLayout(line1, stretch=1)
card_layout.addLayout(line2, stretch=2)
card_layout.addLayout(line3, stretch=8)
card_layout.addLayout(line4)

card_win.resize(400, 300)
card_win.setLayout(card_layout)

