#імпортуємо PyQT5
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication
from random import choice, shuffle
from time import sleep

#створюємо додаток
app = QApplication([])

#Імпортуємо значення з інших файлів
from card_window import *
from main_window import *

#параметри card_window
card_win = QWidget()
card_win.setWindowTitle("memory card")
card_win.resize(600, 500)
card_win.setLayout(card_layout)

#Створення класу для запитань 
class Question:
    def __init__(self, question, answer, wrong_ans1, wrong_ans2, wrong_ans3):
        self.question = question
        self.answer = answer
        self.wrong_ans1 = wrong_ans1
        self.wrong_ans2 = wrong_ans2
        self.wrong_ans3 = wrong_ans3
        self.is_asking = True
        self.count_ask = 0
        self.count_right = 0
    
    #def got_right (self):
        #self.count_ask += 1
        #self.count_right += 1
    #
    #def got_wrong (self):
        #self.count_ask += 1

count_ask = 0
count_right = 0

#створення об'єктів запитань
q1 = Question('банан', 'banana', 'pineapple', 'cucumber', 'dad')
q2 = Question('авто', 'car', 'ship', 'brother', 'sheep')
q3 = Question('телевізор', 'TV', 'phone', 'cat', 'table')
q4 = Question('птах', 'bird', 'T-shirt', 'game', 'glue')

#списки з запитаннями та кнопками
radio_buttons = [rbtn1, rbtn2, rbtn3, rbtn4]
questions = [q1, q2, q3, q4]

#функція для рандомної генерації питання та його відображення
def new_question():
    global cur_quest
    cur_quest = choice(questions)
    lbl_question.setText(cur_quest.question) 
    lbl_correct.setText(cur_quest.answer)

    shuffle(radio_buttons)
    radio_buttons[0].setText(cur_quest.wrong_ans1)
    radio_buttons[1].setText(cur_quest.wrong_ans2)
    radio_buttons[2].setText(cur_quest.wrong_ans3)
    radio_buttons[3].setText(cur_quest.answer)

#викликаємо функцію
new_question()

#перевірка відповіді
def check():
    global count_ask, count_right
    RadioGroup.setExclusive(False)
    for answer in radio_buttons:
        if answer.isChecked():
            if answer.text() == lbl_correct.text():
                count_ask += 1
                count_right += 1
                lbl_result.setText("Правильно")
                answer.setChecked(False)
                break 
    else:
        lbl_result.setText("Не правильно")
        count_ask += 1           
    RadioGroup.setExclusive(True)

#перехід до наступного питання
def switch_screen():
    if btn_ok.text() == 'Відповісти':
        check()
        RadioGroupBox.hide()
        AnswerGroupBox.show()
        btn_ok.setText("Наступне запитання")
    else:
        new_question()
        AnswerGroupBox.hide()
        RadioGroupBox.show()
        btn_ok.setText("Відповісти")

#функція яка зупиняє роботу программі на заданий час
def rest():
    card_win.hide()
    n = box_min.value() * 60
    sleep(n)
    card_win.show()

#фунція яка повертає нас до меню
def back_to_menu():
    if count_ask == 0:
        c = 0
    else:
        c = (count_right/count_ask) * 100
    text = f'Всього відповідей: {count_ask}\n' \
           f'Правильних відповідей: {count_right}\n' \
           f'Успішність: {round(c, 2)}%'
    lbl_stat.setText(text)
    card_win.hide()
    main_win.show()

#фунція яка повертає нас до вікна з питаннями
def to_card():
    main_win.hide()
    card_win.show()

#фунція для очищення полів 
def clear():
    le_quest.clear()
    le_right_ans.clear()
    le_wrong_ans1.clear()
    le_wrong_ans2.clear()
    le_wrong_ans3.clear()

#фунція для додавання запитання в програму 
def add_quest():
    new_q = Question(le_quest.text(), le_right_ans.text(), le_wrong_ans1.text(), le_wrong_ans2.text(), le_wrong_ans3.text())
    questions.append(new_q)
    clear()

#пдіключення кнопок до функцій до кнопок
btn_ok.clicked.connect(switch_screen)
btn_sleep.clicked.connect(rest)
btn_menu.clicked.connect(back_to_menu)
btn_back.clicked.connect(to_card)
btn_clear.clicked.connect(clear)
btn_add_quest.clicked.connect(add_quest)

card_win.show()
app.exec_()






